package spaceStation.models.astronauts;

public class Meteorologist extends BaseAstronaut{
    private static final double INITIAL_UNITS_OF_OXYGEN = 90;

    protected Meteorologist(String name) {
        super(name, INITIAL_UNITS_OF_OXYGEN);
    }
}
